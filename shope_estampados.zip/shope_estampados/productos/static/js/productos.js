// static/js/productos.js

const API_URL = '/api/productos/';

async function loadProducts() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) {
            throw new Error('Error al cargar los productos');
        }
        const data = await response.json();
        displayProducts(data);
    } catch (error) {
        console.error('Error:', error);
        alert('Error al cargar los productos. Por favor, intente nuevamente.');
    }
}

function displayProducts(products) {
    const cardsContainer = document.getElementById('productCards');
    cardsContainer.innerHTML = '';

    products.forEach(product => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';
        card.innerHTML = `
            <div class="card">
                <img class="card-img-top product-image" src="${product.imagen || '/static/placeholder.jpg'}" alt="Producto">
                <div class="card-body">
                    <h5 class="card-title">${product.nombre_producto}</h5>
                    <p class="card-text">Descripción: ${product.descripcion}</p>
                    <p class="card-text">Categoría: ${product.categoria}</p>
                    <p class="card-text">Precio: $${parseInt(product.precio).toLocaleString('es-CL')}</p>
                    <p class="card-text">Disponibilidad: ${product.disponibilidad}</p>
                    <button class="btn btn-danger btn-sm" onclick="deleteProduct(${product.codigo})">Eliminar</button>
                </div>
            </div>
        `;
        cardsContainer.appendChild(card);
    });
}

async function addProduct(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        });

        if (response.ok) {
            alert('Producto guardado correctamente');
            form.reset();
            loadProducts();
        } else {
            const errorData = await response.json();
            alert(`Error al guardar el producto: ${JSON.stringify(errorData)}`);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al guardar el producto. Por favor, intente nuevamente.');
    }
}

async function deleteProduct(id) {
    if (confirm('¿Está seguro de que desea eliminar este producto?')) {
        try {
            const response = await fetch(`${API_URL}${id}/`, {
                method: 'DELETE',
                headers: {
                    'X-CSRFToken': getCookie('csrftoken')
                }
            });
            if (response.ok) {
                loadProducts();
            } else {
                throw new Error('Error al eliminar el producto');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Error al eliminar el producto. Por favor, intente nuevamente.');
        }
    }
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

document.addEventListener('DOMContentLoaded', loadProducts);
document.getElementById('productForm').addEventListener('submit', addProduct);

