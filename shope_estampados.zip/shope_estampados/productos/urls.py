from django.urls import path, include
from django.contrib.auth import views as auth_views
from .views import listar_productos, crear_producto, home, nosotros, producto, registro, login, carrito, limpiar_carrito, DetalleBoleta, tienda, perfil, cerrar_login, mostrar, generarBoleta, agregar_al_carrito
from rest_framework.routers import DefaultRouter
from .views import ProductoViewSet
from . import views
from .views import ProductoViewSet, gestionar_producto_view



router = DefaultRouter()
router.register(r'productos', ProductoViewSet)  # Ruta para la API de productos

urlpatterns = [
    path('home/', home, name='index'),  # Ruta para la raíz
    path('nosotros/' , nosotros , name='nosotros' ),
    path('producto/' , producto , name='producto'),
    path('registro/' , registro , name='registro'),
    path('login/', login, name='login'), 
    path('carrito/' , carrito, name='carrito'),
    path('limpiar/', limpiar_carrito, name = "limpiar"),
    path('detalle/', DetalleBoleta, name='detalle_boleta' ),
    path('tienda/', tienda , name='tienda'),
    path('cerrar/', cerrar_login, name = "cerrar_login"),
    path('perfil/', perfil, name = "perfil"),
    path('mostrar/', mostrar, name = "mostrar"),
    path('generar/boleta' , generarBoleta , name='generarBoleta'),
    path('gestionar-producto/', gestionar_producto_view, name='gestionar_producto'),
    path('agregar_al_carrito/<int:producto_id>/', agregar_al_carrito, name='agregar_al_carrito'),
    path('', include(router.urls)),
    
] 