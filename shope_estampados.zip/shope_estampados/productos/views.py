from django.shortcuts import render , get_object_or_404 , redirect
from .models import Producto ,Usuario,Boleta,DetalleBoleta
from .forms import ProductoForm,UsuarioForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as auth_login  
from .compra import Carrito
from rest_framework import viewsets
from .serializers import ProductoSerializer

# Create your views here.
def home(request):
    return render(request, 'index.html')

def nosotros(request):
    return render(request, 'nosotros.html')


def registro(request):
    if request.method == 'POST':
        form = UsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = UsuarioForm()
    return render(request, 'registro.html', {'form': form})

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def carrito(request):
    return render(request, 'carrito.html')
# Leer (listar productos)
def listar_productos(request):
    productos = Producto.objects.all()
    return render(request, 'productos/listar_productos.html', {'productos': productos})

def producto(request):
    return render(request , 'producto.html')

# Crear
@login_required
def crear_producto(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('producto')
    else:
        form = ProductoForm()
    return render(request, 'tienda.html', {'form': form})

# Actualizar
def actualizar_producto(request, id_producto):
    producto = get_object_or_404(Producto, id_producto=id_producto)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('listar_productos')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'mostra.html', {'form': form})

# Eliminar
def eliminar_producto(request, id_producto):
    producto = get_object_or_404(Producto, id_producto=id_producto)
    if request.method == 'POST':
        producto.delete()
        return redirect('listar_productos')
    return render(request, 'productos/eliminar_producto.html', {'producto': producto})


def limpiar_carrito(request):
    carrito_compra = Carrito(request)
    carrito_compra.limpiar()
    return redirect('tienda')

def generarBoleta(request):
    precio_total=0
    for key, value in request.session['carrito'].items():
        precio_total = precio_total + int(value['precio']) * int(value['cantidad'])
    boleta = Boleta(total = precio_total)
    boleta.save()
    productos = []
    for key, value in request.session['carrito'].items():
            producto = Producto.objects.get(codigo = value['producto_id'])
            cant = value['cantidad']
            subtotal = cant * int(value['precio'])
            detalle = DetalleBoleta(id_boleta = boleta, id_producto = producto, cantidad = cant, subtotal = subtotal)
            detalle.save()
            productos.append(detalle)
    datos={
        'productos': productos,
        'fecha': boleta.fecha_compra,
        'total': boleta.total
    }
    request.session['boleta'] = boleta.id_boleta
    carrito = Carrito(request)
    carrito.limpiar()
    return render(request, 'DetalleCarrito.html',datos)

def tienda(request):
    productito = Producto.objects.all()
    datos ={
        'producto':productito
    }
    return render(request, 'tienda.html')

@login_required
def cerrar_login(request):
    if request.method == 'POST':
        logout(request)
        return redirect('index')  # Redirige a la página principal después de cerrar sesión
    return render(request, 'cerrar_login.html')

def perfil(request):
    return render(request, 'perfil.html')
def mostrar(request):
    productos = Producto.objects.all()
    return render(request, 'mostrar.html' , {'productos': productos})

    

    

def agregar_al_carrito(request, producto_id):
    producto = get_object_or_404(Producto, codigo=producto_id)
    carrito = request.session.get('carrito', {})
    carrito.agregar(producto)

    if str(producto.id) in carrito:
        carrito[str(producto.id)]['cantidad']+=1
    else:
        carrito[str(producto.id)]={
            'producto_id':producto.codigo,
            'nombre': producto.nombre_producto,
            'precio': producto.precio,
            'cantidad': 1
        }
    request.session['carrito'] = carrito
    return redirect('tienda')


def gestionar_producto_view(request):
    return render(request, 'gestionar_producto.html')

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer


def carrito(request):
    carrito = Carrito(request)  # Crea una instancia del carrito
    productos = carrito.carrito  # Obtiene los productos del carrito
    total_precio = carrito.total_precio()  # Calcula el precio total
    return render(request, 'carrito.html', {'productos': productos, 'total_precio': total_precio})