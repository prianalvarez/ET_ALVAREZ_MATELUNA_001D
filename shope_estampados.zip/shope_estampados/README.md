usuario: estampados
contraseña: duocuc2025

intalar pip
   pip install pillow

instalar djangorestframework
    pip install djangorestframework

correr el programa
    python manage.py runserver


